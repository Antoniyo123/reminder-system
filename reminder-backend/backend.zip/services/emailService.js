// services/emailService.js
const nodemailer = require('nodemailer');
require('dotenv').config();

class EmailService {
  constructor() {
 this.transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  },
  // Opsi tambahan untuk menghindari beberapa issue
  tls: {
    rejectUnauthorized: false
  }
});
  }

  async sendReminderEmail(emailData) {
    try {
      const { to, subject, body, recipient } = emailData;

      const htmlTemplate = this.generateHTMLTemplate(body, recipient);

      const mailOptions = {
        from: process.env.EMAIL_FROM || process.env.EMAIL_USER,
        to: to,
        subject: subject,
        html: htmlTemplate,
        text: body // Fallback text version
      };

      console.log('📧 Attempting to send email to:', to);
      
      const result = await this.transporter.sendMail(mailOptions);
      
      console.log('✅ Email sent successfully:', result.messageId);
      
      return {
        success: true,
        messageId: result.messageId,
        response: result.response
      };

    } catch (error) {
      console.error('❌ Email sending failed:', error);
      throw new Error(`Failed to send email: ${error.message}`);
    }
  }

  generateHTMLTemplate(body, recipient) {
    const formattedDate = new Date(recipient.tanggalExp).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    return `
      <!DOCTYPE html>
      <html>
      <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Visa Reminder</title>
          <style>
              body { 
                  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                  line-height: 1.6; 
                  color: #333; 
                  margin: 0; 
                  padding: 0; 
                  background-color: #f9f9f9;
              }
              .container { 
                  max-width: 600px; 
                  margin: 0 auto; 
                  background: white;
                  border-radius: 10px;
                  overflow: hidden;
                  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
              }
              .header { 
                  background: linear-gradient(135deg, #f4c430, #e6b82e); 
                  padding: 30px 20px; 
                  text-align: center; 
                  color: #2c3e50; 
              }
              .header h1 { 
                  margin: 0; 
                  font-size: 28px;
                  font-weight: 700;
              }
              .header p {
                  margin: 10px 0 0 0;
                  font-size: 16px;
                  opacity: 0.9;
              }
              .content { 
                  padding: 30px; 
              }
              .footer { 
                  text-align: center; 
                  padding: 20px; 
                  color: #666; 
                  font-size: 12px; 
                  background: #f8f9fa;
                  border-top: 1px solid #e9ecef;
              }
              .info-section {
                  background: #f8f9fa;
                  border-radius: 8px;
                  padding: 20px;
                  margin: 20px 0;
                  border-left: 4px solid #f4c430;
              }
              .info-item { 
                  margin: 12px 0; 
                  display: flex;
                  justify-content: space-between;
              }
              .info-label { 
                  font-weight: 600; 
                  color: #2c3e50; 
                  min-width: 150px;
              }
              .info-value { 
                  color: #495057;
                  text-align: right;
                  flex: 1;
              }
              .urgent { 
                  color: #dc2626; 
                  font-weight: 700; 
                  background: #fef2f2; 
                  padding: 4px 8px; 
                  border-radius: 4px;
                  display: inline-block;
              }
              .message-body {
                  background: white;
                  border: 1px solid #e9ecef;
                  border-radius: 8px;
                  padding: 20px;
                  margin: 20px 0;
                  white-space: pre-line;
                  line-height: 1.8;
              }
              .logo {
                  font-size: 24px;
                  font-weight: bold;
                  color: #2c3e50;
                  margin-bottom: 10px;
              }
              @media (max-width: 600px) {
                  .container {
                      margin: 10px;
                      border-radius: 8px;
                  }
                  .content {
                      padding: 20px;
                  }
                  .info-item {
                      flex-direction: column;
                  }
                  .info-value {
                      text-align: left;
                      margin-top: 4px;
                  }
              }
          </style>
      </head>
      <body>
          <div class="container">
              <div class="header">
                  <h1>🔔 Visa Reminder</h1>
                  <p>Pengingat Dokumen Keimigrasian</p>
              </div>
              
              <div class="content">
                  <div class="logo">VisaReminder</div>
                  
                  <div class="message-body">
                      ${body.replace(/\n/g, '<br>')}
                  </div>
                  
                  <div class="info-section">
                      <div class="info-item">
                          <span class="info-label">Nama:</span>
                          <span class="info-value">${recipient.nama}</span>
                      </div>
                      <div class="info-item">
                          <span class="info-label">Perusahaan:</span>
                          <span class="info-value">${recipient.perusahaan}</span>
                      </div>
                      <div class="info-item">
                          <span class="info-label">Jenis Dokumen:</span>
                          <span class="info-value">${recipient.jenisKitas}</span>
                      </div>
                      <div class="info-item">
                          <span class="info-label">Tanggal Expired:</span>
                          <span class="info-value">
                              <span class="urgent">${formattedDate}</span>
                          </span>
                      </div>
                      <div class="info-item">
                          <span class="info-label">Email:</span>
                          <span class="info-value">${recipient.email}</span>
                      </div>
                  </div>
                  
                  <p style="color: #666; font-size: 14px; text-align: center; margin-top: 30px;">
                      <strong>Segera hubungi tim imigrasi untuk memperpanjang dokumen Anda.</strong>
                  </p>
              </div>
              
              <div class="footer">
                  <p>Email ini dikirim secara otomatis. Mohon tidak membalas email ini.</p>
                  <p>Jika Anda memiliki pertanyaan, hubungi administrator sistem.</p>
                  <p>&copy; ${new Date().getFullYear()} Visa Reminder System. All rights reserved.</p>
              </div>
          </div>
      </body>
      </html>
    `;
  }

  async verifyConnection() {
    try {
      await this.transporter.verify();
      console.log('✅ Email server connection verified');
      return { 
        success: true, 
        message: 'Email server is ready to send messages' 
      };
    } catch (error) {
      console.error('❌ Email connection failed:', error);
      return { 
        success: false, 
        error: 'Email server connection failed: ' + error.message 
      };
    }
  }
}

module.exports = new EmailService();